// Shared utility library for DebtZero
// These are the canonical implementations — do not rewrite in other files.

/**
 * Format a number as USD currency string.
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Format a number of months into a human-readable string.
 * e.g. 14 → "1 yr 2 mo", 6 → "6 mo"
 */
export function formatMonths(months: number): string {
  if (!isFinite(months) || months <= 0) return "—";
  const yrs = Math.floor(months / 12);
  const mo = Math.round(months % 12);
  if (yrs === 0) return `${mo} mo`;
  if (mo === 0) return `${yrs} yr`;
  return `${yrs} yr ${mo} mo`;
}

/**
 * Months to pay off a balance given APR and a fixed monthly payment.
 * Returns Infinity if payment is ≤ monthly interest (balance never paid off).
 */
export function monthsToPayoff(
  balance: number,
  annualAPR: number,
  monthlyPayment: number
): number {
  if (balance <= 0) return 0;
  const monthlyRate = annualAPR / 100 / 12;
  if (monthlyRate === 0) {
    return balance / monthlyPayment;
  }
  const monthlyInterest = balance * monthlyRate;
  if (monthlyPayment <= monthlyInterest) return Infinity;
  return (
    -Math.log(1 - (balance * monthlyRate) / monthlyPayment) /
    Math.log(1 + monthlyRate)
  );
}

/**
 * Total interest paid over the life of a loan given APR and a fixed monthly payment.
 */
export function totalInterestPaid(
  balance: number,
  annualAPR: number,
  monthlyPayment: number
): number {
  const months = monthsToPayoff(balance, annualAPR, monthlyPayment);
  if (!isFinite(months)) return Infinity;
  return Math.max(0, monthlyPayment * months - balance);
}

/**
 * Required monthly payment to pay off a balance within a given number of months.
 */
export function requiredMonthlyPayment(
  balance: number,
  annualAPR: number,
  months: number
): number {
  if (balance <= 0 || months <= 0) return 0;
  const monthlyRate = annualAPR / 100 / 12;
  if (monthlyRate === 0) return balance / months;
  return (
    (balance * monthlyRate * Math.pow(1 + monthlyRate, months)) /
    (Math.pow(1 + monthlyRate, months) - 1)
  );
}

/**
 * Calculate the transfer fee amount.
 */
export function transferFee(balance: number, feePercent: number): number {
  return balance * (feePercent / 100);
}
